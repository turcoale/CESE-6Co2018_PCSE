/* Copyright 2014, ChaN
 * Copyright 2016, Matias Marando
 * All rights reserved.
 *
 * This file is part of Workspace.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/** @brief This is an SD card write example using the FatFs library
 */

/** \addtogroup spi SD card write via SPI
 ** @{ */

/*==================[inclusions]=============================================*/

#include "board.h"
#include "ff.h"
#include "sapi.h"

/*==================[macros and definitions]=================================*/

#define BAUD_RATE 9600

/*==================[internal data declaration]==============================*/

static uint32_t ms_ticks;  /**< 1ms timeticks counter */
static FATFS fs;           /**< FatFs work area needed for each volume */
static FIL fp;             /**< File object needed for each open file */

static delay_t delayBase;
RTC_t rtc;

static int16_t hmc5883l_x_raw;
static int16_t hmc5883l_y_raw;
static int16_t hmc5883l_z_raw;

/* Buffers */
static uint8_t uartBuff[10];

/*==================[internal functions declaration]=========================*/

/** @brief Hardware initialization function
 *  @return none
 */
static void initHardware(void);

/*==================[internal functions definition]==========================*/

static void initHardware(void)
{
    Board_Init();
    SystemCoreClockUpdate();
    SysTick_Config(SystemCoreClock / 1000);

    /* SPI configuration */
    Board_SSP_Init(LPC_SSP1);
    Chip_SSP_Init(LPC_SSP1);
    Chip_SSP_Enable(LPC_SSP1);
}

char* itoa(int value, char* result, int base) {
   // check that the base if valid
   if (base < 2 || base > 36) { *result = '\0'; return result; }

   char* ptr = result, *ptr1 = result, tmp_char;
   int tmp_value;

   do {
      tmp_value = value;
      value /= base;
      *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
   } while ( value );

   // Apply negative sign
   if (tmp_value < 0) *ptr++ = '-';
   *ptr-- = '\0';
   while(ptr1 < ptr) {
      tmp_char = *ptr;
      *ptr--= *ptr1;
      *ptr1++ = tmp_char;
   }
   return result;
}

void sendHmc5883lToUart( int16_t axis, uint8_t axisName ){

   /* Envio la primer parte dle mensaje a la Uart */
   uartWriteString( UART_USB, (uint8_t*) "HMC5883L eje ");
   uartWriteByte( UART_USB, axisName );
   uartWriteString( UART_USB, (uint8_t*) ": ");

   /* Conversion de muestra entera a ascii con base decimal */
   itoa( (int) axis, (char*)uartBuff, 10 ); /* 10 significa decimal */

   /* Envio el valor del eje */
   uartBuff[4] = 0;    /* NULL */
   uartWriteString( UART_USB, uartBuff );

   /* Envio un 'enter' */
   uartWriteString( UART_USB, (uint8_t*) "\r\n");
}

/*==================[external functions definition]==========================*/

FRESULT open_append (
    FIL* fp,            /* [OUT] File object to create */
    const char* path    /* [IN]  File name to be opened */
)
{
    FRESULT fr;

    /* Opens an existing file. If not exist, creates a new file. */
    fr = f_open(fp, path, FA_WRITE | FA_OPEN_ALWAYS);
    if (fr == FR_OK) {
        /* Seek to end of the file to append data */
        fr = f_lseek(fp, f_size(fp));
        if (fr != FR_OK)
            f_close(fp);
    }
    return fr;
}


int main(void)
{
    UINT nbytes;

    initHardware();

    boardConfig();

    tickConfig(1,0);

    rtc.sec     = 0;
    rtc.min     = 0;
    rtc.hour       = 14;
    rtc.mday = 29;
    rtc.month      = 11;
    rtc.year       = 2016;

    rtcConfig( &rtc );

    /* Inicializar HMC5883L */
    HMC5883L_config_t hmc5883L_configValue;

    hmc5883lPrepareDefaultConfig( &hmc5883L_configValue );

    hmc5883L_configValue.mode = HMC5883L_continuous_measurement;
    hmc5883L_configValue.samples = HMC5883L_8_sample;

    hmc5883lConfig( hmc5883L_configValue );

    uartConfig(UART_USB, BAUD_RATE);
    delayConfig(&delayBase,1000);

    digitalConfig( 0, ENABLE_DIGITAL_IO );

    uartWriteString(UART_USB, (uint8_t*) "Init ejemplo\r\n");

    uint8_t count=0;
    uint8_t size_data=0;
    uint8_t num[10];
    uint8_t file_name[20]="file";
    uint8_t data[200]="";
    uint8_t aux[10]="";

    /* Give a work area to the default drive */
    if (f_mount(&fs, "", 0) != FR_OK) {
        /* If this fails, it means that the function could
         * not register a file system object.
         * Check whether the SD card is correctly connected */
    }
    strcpy(file_name,"filePrueba.txt");

    /* Create/open a file, then write a string and close it */
    if (f_open(&fp, "file.txt", FA_WRITE | FA_CREATE_ALWAYS) == FR_OK) {
        f_write( &fp,
        		 "CAPSE: Usamos SPI y FileSystem para grabar datos en una memoria SD\r\n",
				 68,
				 &nbytes
			   );





        if (nbytes == 68) {
            /* Toggle a LEDG if the write operation was successful */
            Board_LED_Toggle(1);
        }
    } else{
        /* Toggle a LEDR if fails */
        Board_LED_Toggle(0);
    }



    while (1) {
    	if (delayRead(&delayBase))
    	{


    		count++;
//    		itoa( count, num, 10 );
//    		strcpy(file_name,"file");
//    		strcat(file_name,num);
//    		strcat(file_name,".txt");



    		rtcRead( &rtc );
    		strcpy(data,"La fecha es ");
    		itoa(rtc.year, aux , 10 );
    		strcat(data,aux);
    		strcat(data,"-");
    		itoa(rtc.month, aux , 10 );
    		strcat(data,aux);
    		strcat(data,"-");
    		itoa( rtc.mday,aux,  10 );
    		strcat(data,aux);
    		strcat(data," y hora ");
    		itoa( rtc.hour,aux,  10 );
    		strcat(data,aux);
    		strcat(data,":");
    		itoa(rtc.min, aux,  10 );
    		strcat(data,aux);
    		strcat(data,":");
    		itoa(rtc.sec, aux,  10 );
    		strcat(data,aux);
    		strcat(data,"\r\n");

    		uartWriteString(UART_USB, &data);

    	      hmc5883lRead( &hmc5883l_x_raw, &hmc5883l_y_raw, &hmc5883l_z_raw );
    	      /* Se debe esperar minimo 67ms entre lecturas su la tasa es de 15Hz
    	        para leer un nuevo valor del magnetómetro */

    	      sendHmc5883lToUart( hmc5883l_x_raw, 'x' );
    	      sendHmc5883lToUart( hmc5883l_y_raw, 'y' );
    	      sendHmc5883lToUart( hmc5883l_z_raw, 'z' );

    	      /* Envio un 'enter' */
    	      uartWriteString( UART_USB, (uint8_t*) "\r\n");


    		for (size_data = 0; size_data < data[size_data]!= 0; size_data++);

    		/* Create/open a file, then write a string and close it */
    		if (open_append(&fp, "file.txt") == FR_OK) {
    			f_printf( &fp,&data);

    			Board_LED_Toggle(1);
    			f_close(&fp);
    		}

    		else{
    			/* Toggle a LEDR if fails */
    			Board_LED_Toggle(0);
    		}
    	}
    }

    return 0;
}

/** @} doxygen end group definition */

/*==================[end of file]============================================*/
